package Clases;
//hola XD
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class consultas {
    public void guardarUsuario(String usuario, String password) {
        ConexionDB db = new ConexionDB();
        String sql = "INSERT INTO usuarios(nombre, clave) VALUES (?, ?)";
        
        try (Connection conexion = db.conectar();
             PreparedStatement statement = conexion.prepareStatement(sql)) {
            statement.setString(1, usuario);
            statement.setString(2, password);
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Guardado correctamente");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al guardar usuario: " + e.getMessage());
        } finally {
            db.cerrarConexion();
        }
    }

    public boolean consultarUsuario(String user, String pass) {
    ConexionDB db = new ConexionDB();
    String sql = "SELECT nombre, clave FROM usuarios WHERE nombre = ?";
    
    try (Connection cn = db.conectar();
         PreparedStatement pst = cn.prepareStatement(sql)) {
        pst.setString(1, user);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            String usuarioCorrecto = rs.getString("nombre");
            String passCorrecto = rs.getString("clave");

            if (user.equals(usuarioCorrecto) && pass.equals(passCorrecto)) {
                JOptionPane.showMessageDialog(null, "Login correcto. Bienvenido " + user);
                return true; // Devuelve true si las credenciales son correctas
            } else {
                JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Usuario no encontrado");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al consultar usuario: " + e.getMessage());
    } finally {
        db.cerrarConexion();
    }
    
    return false; // Devuelve false si las credenciales no son correctas
}

}
