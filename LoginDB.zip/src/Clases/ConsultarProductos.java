package Clases;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class ConsultarProductos {
    public boolean guardarProducto(String sede, String pasillo, String nombreProducto, double precio, int cantidad) {
        ConexionPD db = new ConexionPD();
        String sql = "INSERT INTO productos(sede, pasillo, nombre, precio, cantidad) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conexion = db.conectar();
             PreparedStatement statement = conexion.prepareStatement(sql)) {
            statement.setString(1, sede);
            statement.setString(2, pasillo);
            statement.setString(3, nombreProducto);
            statement.setDouble(4, precio);
            statement.setInt(5, cantidad);
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Producto guardado correctamente");
                return true; // Importante: devolver verdadero si la inserción fue exitosa.
            } else {
                JOptionPane.showMessageDialog(null, "Error al guardar producto");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al guardar producto: " + e.getMessage());
        } finally {
            db.cerrarConexion();
        }
        
        return false; // Retornar falso si hay un error.
    }

    public boolean consultarProducto(String nombre) {
        ConexionPD db = new ConexionPD();
        String sql = "SELECT sede, pasillo, precio, cantidad FROM productos WHERE nombre = ?";
        
        try (Connection cn = db.conectar();
             PreparedStatement pst = cn.prepareStatement(sql)) {
            pst.setString(1, nombre);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                String sede = rs.getString("sede");
                int pasillo = rs.getInt("pasillo");
                double precio = rs.getDouble("precio");
                int cantidad = rs.getInt("cantidad");
                
                JOptionPane.showMessageDialog(null, "Producto encontrado: Sede: " + sede + ", Pasillo: " + pasillo + ", Precio: " + precio + ", Cantidad: " + cantidad);
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Producto no encontrado");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al consultar producto: " + e.getMessage());
        } finally {
            db.cerrarConexion();
        }
        
        return false;
    }

    public Producto getProductoPorId(int id) {
        ConexionPD db = new ConexionPD();
        String sql = "SELECT sede, pasillo, nombre, precio, cantidad FROM productos WHERE id = ?";
        
        try (Connection cn = db.conectar();
             PreparedStatement pst = cn.prepareStatement(sql)) {
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                String sede = rs.getString("sede");
                String pasillo = rs.getString("pasillo");
                String nombre = rs.getString("nombre");
                double precio = rs.getDouble("precio");
                int cantidad = rs.getInt("cantidad");

                return new Producto(id, sede, pasillo, nombre, precio, cantidad);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener producto por ID: " + e.getMessage());
        } finally {
            db.cerrarConexion();
        }

        return null;
    }

    public boolean actualizarProducto(int id, String sede, String pasillo, String nombre, double precio, int cantidad) {
    ConexionPD db = new ConexionPD();
    String sql = "UPDATE productos SET sede = ?, pasillo = ?, nombre = ?, precio = ?, cantidad = ? WHERE id = ?";
    
    try (Connection cn = db.conectar();
         PreparedStatement pst = cn.prepareStatement(sql)) {
        pst.setString(1, sede);
        pst.setString(2, pasillo);
        pst.setString(3, nombre);
        pst.setDouble(4, precio);
        pst.setInt(5, cantidad);
        pst.setInt(6, id);

        int rowsUpdated = pst.executeUpdate();
        if (rowsUpdated > 0) {
            JOptionPane.showMessageDialog(null, "Producto actualizado correctamente");
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Error al actualizar producto. Producto no encontrado.");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al actualizar producto: " + e.getMessage());
    } finally {
        db.cerrarConexion();
    }

    return false;
}

    // Otros métodos de la clase...
}
