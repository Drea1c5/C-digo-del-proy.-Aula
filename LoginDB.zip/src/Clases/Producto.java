package Clases;

public class Producto {
    private int id;
    private String sede;
    private String pasillo;
    private String nombre;
    private double precio;
    private int cantidad;

    // Constructor
    public Producto(int id, String sede, String pasillo, String nombre, double precio, int cantidad) {
        this.id = id;
        this.sede = sede;
        this.pasillo = pasillo;
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    // Getters y setters (métodos para acceder y modificar los atributos)

    public int getId() {
        return id;
    }

    public String getSede() {
        return sede;
    }

    public String getPasillo() {
        return pasillo;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public int getCantidad() {
        return cantidad;
    }
}
